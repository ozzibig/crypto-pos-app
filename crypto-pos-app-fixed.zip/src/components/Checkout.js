import { useState, useEffect } from 'react';

export default function Checkout() {
  const [euro, setEuro] = useState(0);
  const [usd, setUsd] = useState(0);
  const conversionRate = 1.09;

  useEffect(() => {
    setUsd((euro * conversionRate).toFixed(2));
  }, [euro]);

  return (
    <div>
      <label>Importo in EUR</label>
      <input
        type="number"
        value={euro}
        onChange={(e) => setEuro(parseFloat(e.target.value) || 0)}
        style={{ width: '100%', padding: 8, fontSize: 18 }}
      />
      <p>≈ {usd} USD</p>
      <p>1 EUR = {conversionRate} USD</p>
      <button style={{ width: '100%', padding: 12, backgroundColor: '#0070f3', color: '#fff', border: 'none', borderRadius: 6 }}>
        Accetta crypto selezionata
      </button>
    </div>
  );
}