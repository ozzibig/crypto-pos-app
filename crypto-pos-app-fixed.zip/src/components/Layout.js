import Link from 'next/link';

export default function Layout({ title, children }) {
  return (
    <div style={{ aspectRatio: '9/16', maxWidth: 400, margin: '0 auto', padding: 16 }}>
      <h1>{title}</h1>
      <div style={{ margin: '20px 0' }}>{children}</div>
      <nav style={{ position: 'fixed', bottom: 10, left: 0, right: 0, textAlign: 'center' }}>
        <Link href="/checkout">Checkout</Link> |{' '}
        <Link href="/transactions">Transazioni</Link> |{' '}
        <Link href="/payouts">Bonifici</Link> |{' '}
        <Link href="/products">Prodotti</Link> |{' '}
        <Link href="/settings">Impostazioni</Link>
      </nav>
    </div>
  );
}