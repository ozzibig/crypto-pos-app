import Layout from '../components/Layout';
import Checkout from '../components/Checkout';

export default function CheckoutPage() {
  return (
    <Layout title="Checkout">
      <Checkout />
    </Layout>
  );
}