import Layout from '../components/Layout';

export default function PayoutsPage() {
  return (
    <Layout title="Bonifici Ricevuti">
      <p>Lista bonifici ricevuti dall’azienda.</p>
    </Layout>
  );
}