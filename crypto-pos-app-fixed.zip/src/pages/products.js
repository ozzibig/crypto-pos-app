import Layout from '../components/Layout';

export default function ProductsPage() {
  return (
    <Layout title="Prodotti">
      <p>Gestione e listino rapido prodotti.</p>
    </Layout>
  );
}