import Layout from '../components/Layout';

export default function SettingsPage() {
  return (
    <Layout title="Impostazioni">
      <p>Profilo, IBAN, contatti e logout.</p>
    </Layout>
  );
}