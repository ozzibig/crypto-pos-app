import Layout from '../components/Layout';

export default function TransactionsPage() {
  return (
    <Layout title="Transazioni">
      <p>Storico delle transazioni in crypto.</p>
    </Layout>
  );
}